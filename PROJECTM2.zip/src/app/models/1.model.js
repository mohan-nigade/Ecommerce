//create Mongoose data model


module.exports = mongoose => {
    var schema = mongoose.Schema(
      {
        title: String,
        description: String,
        Category:String,
        MRP:String,
        CreationDate:String,
        ExpireDate:String,
        published: Boolean
      },
      { timestamps: true }
    );
    //use this app with a front-end that needs id field 
    //instead of _id, you have to override toJSON method that map default object to a custom object.
    schema.method("toJSON", function() {
      const { __v, _id, ...object } = this.toObject();
      object.id = _id;
      return object;
    });
    const Product = mongoose.model("product", schema);
    return Product;
  };






  //After finishing the steps above, we don’t need to write CRUD functions, Mongoose Model supports all of them
/*create a new Tutorial: object.save()
find a Tutorial by id: findById(id)
retrieve all Tutorials: find()
update a Tutorial by id: findByIdAndUpdate(id, data)
remove a Tutorial: findByIdAndRemove(id)
remove all Tutorials: deleteMany()
find all Tutorials by title: find({ title: { $regex: new RegExp(title), $options: “i” } })
These functions will be used in our Controller.*/
