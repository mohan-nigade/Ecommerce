import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-design1',
  templateUrl: './design1.component.html',
  styleUrls: ['./design1.component.scss']
})
export class Design1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  
}
