import { Component, OnInit } from '@angular/core';
import { MohanService } from 'src/app/services/mohan.service';
import{FormControl,FormBuilder,FormGroup,Validators, FormArray} from '@angular/forms'
@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.scss']
})
export class AddComponent implements OnInit {
  userForm:FormGroup;
  
  product = {
    title: '',
    description: '',
    Category:'',
    MRP:'',
    CreationDate:'',
    ExpireDate:'', 
    published: false
  };
  submitted = false;
  constructor(private mohanService: MohanService,private fb:FormBuilder) { }
  ngOnInit() {
    this.userForm=new FormGroup({
      title:new FormControl(''),
      description:new FormControl(''),
      Category:new FormControl(''),
      MRP:new FormControl(''),
      CreationDate:new FormControl(''),
      ExpireDate:new FormControl('')


    })
    this.userForm=this.fb.group({
      title:['',[Validators.required,Validators.minLength(3),Validators.maxLength(7),
        Validators.pattern('^[0-9]*$')]],
        description:['',[Validators.required,Validators.minLength(3),Validators.maxLength(15)]],
     
        Category:['',[Validators.required,Validators.minLength(3),Validators.maxLength(7),
          Validators.pattern('^[a-zA-Z]+$')]],
       MRP:['',[Validators.required,Validators.minLength(3),Validators.maxLength(7),
        Validators.pattern('^[0-9]*$')]],
       
       CreationDate:['',[Validators.required]],
       ExpireDate:['',[Validators.required]]
    })
    
  }
  //////////
  Categoryy:string[]=['Perfume','Cloth','Bag','Shoes']

  get title(){
    return this.userForm.get('title')
  }

  get description(){
    return this.userForm.get('description')
  }
  
  get Category(){
    return this.userForm.get('Category')
  }

  get MRP(){
    return this.userForm.get('MRP')
  }

  get CreationDate(){
    return this.userForm.get('CreationDate')
  }
  get ExpireDate(){
    return this.userForm.get('ExpireDate')
  }

// It calls Service.create() method.

  saveProduct() {
    const data = {
      title: this.product.title,
      description: this.product.description,
      Category:this.product.Category,
      MRP:this.product.MRP,
      CreationDate:this.product.CreationDate,
      ExpireDate:this.product.ExpireDate

    };
    this.mohanService.create(data)
      .subscribe(
        response => {
          console.log(response);
          this.submitted = true;
        },
        error => {
          console.log(error);
        });
  }
  newProduct() {
    this.submitted = false;
    this.product = {
      title: '',
      description: '',
      Category:'',
      MRP:'',
      CreationDate:'',
      ExpireDate:'',

      published: false
    };
  }

}



