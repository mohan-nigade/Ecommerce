import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MohanService } from 'src/app/services/mohan.service';
import{FormControl,FormBuilder,FormGroup,Validators, FormArray} from '@angular/forms'
@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.scss']
})
export class DetailsComponent implements OnInit {
  userForm:FormGroup;
  currentProduct = null;
  message = '';
  
  constructor(
    private mohanService: MohanService,
    private route: ActivatedRoute,
    private router: Router,
    private fb:FormBuilder) { }
  ngOnInit() {
    this.message = '';
    this.getProduct(this.route.snapshot.paramMap.get('id'));
    this.userForm=new FormGroup({
      title:new FormControl(''),
      description:new FormControl(''),
      Category:new FormControl(''),
      MRP:new FormControl(''),
      CreationDate:new FormControl(''),
      ExpireDate:new FormControl('')


    })
    this.userForm=this.fb.group({
      title:['',[Validators.required,Validators.minLength(3),Validators.maxLength(7),
        Validators.pattern('^[0-9]*$')]],
        description:['',[Validators.required,Validators.minLength(3),Validators.maxLength(15)]],
     
      Category:['',[Validators.required,Validators.minLength(3),Validators.maxLength(7),
        Validators.pattern('^[a-zA-Z]+$')]],
       MRP:['',[Validators.required,Validators.minLength(3),Validators.maxLength(7),
        Validators.pattern('^[0-9]*$')]],
       
       CreationDate:['',[Validators.required]],
       ExpireDate:['',[Validators.required]]
    })
  }

  Categoryy:string[]=['Perfume','Cloth','Bag','Shoes']

  get title(){
    return this.userForm.get('title')
  }

  get description(){
    return this.userForm.get('description')
  }
  
  get Category(){
    return this.userForm.get('Category')
  }

  get MRP(){
    return this.userForm.get('MRP')
  }

  get CreationDate(){
    return this.userForm.get('CreationDate')
  }
  get ExpireDate(){
    return this.userForm.get('ExpireDate')
  }


//This component calls 3 Service methods:

//getAll()
//update()
//delete()

getProduct(id) {

  this.mohanService.get(id)

    .subscribe({

      next:(data) => {

        this.currentProduct = data;

        console.log(data);

      },

      error:(err) => {

        console.log(err);

      }

    });

}
 /* updatePublished(status) {
    const data = {
      title: this.currentProduct.title,
      description: this.currentProduct.description,
      MRP:this.currentProduct.MRP,
      Category:this.currentProduct.Category,
      CreationDate:this.currentProduct.CreationDate,
      ExpireDate:this.currentProduct.ExpireDate,
      published: status
    };
    this.mohanService.update(this.currentProduct.id, data)
      .subscribe(
        response => {
          this.currentProduct.published = status;
          console.log(response);
        },
        error => {
          console.log(error);
        });
  }*/
  updateProduct() {

    this.mohanService.update(this.currentProduct.id, this.currentProduct)

      .subscribe({

       next: (response) => {

          console.log(response);

          alert('The product was updated successfully!')

          this.router.navigate(['/tutorials']);

          this.message = 'The product was updated successfully!';

        },

        error: (err) => {

          console.log(err);

        }

      });

  }
  deleteProduct() {

    this.mohanService.delete(this.currentProduct.id)

      .subscribe({

        next:(response) => {

          console.log(response);

          alert('The product was deleted successfully!')

          this.router.navigate(['/tutorials']);

        },

        error:(err) => {

          console.log(err);

        }

      });

  }
  
}

