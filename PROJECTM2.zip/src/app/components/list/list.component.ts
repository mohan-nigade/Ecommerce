import { Component, OnInit } from '@angular/core';
import { MohanService } from 'src/app/services/mohan.service';
@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.scss']
})
export class ListComponent implements OnInit {
  products: any;
  currentProduct = null;
  //currentIndex = -1;
  title = '';
  
  constructor(private mohanService: MohanService) { }
  ngOnInit() {
    this.retrieveProducts();
  }
////This component calls 3 Service methods:

//getAll()
//deleteAll()
//findByTitle()

retrieveProducts() {

  this.mohanService.getAll()

    .subscribe({

      next:(data) => {

        this.products = data;

        console.log(data);

      },

      error:(err) => {

        console.log(err);

      }

    });

}



removeAllProducts() {

  this.mohanService.deleteAll()

    .subscribe({

      next:(response) => {

        console.log(response);

        this.retrieveProducts();

      },

      error:(error) => {

        console.log(error);

      }

    });

}

searchTitle() {

  this.mohanService.findByTitle(this.title)

    .subscribe({

      next:(data) => {

        this.products = data;

        console.log(data);

      },

      error:(error) => {

        console.log(error);

      }

    });

}

  
key:string='id'
reverse:boolean=false
  sort(key){
    this.key=key;
    this.reverse=!this.reverse

  }
}
