import { TestBed } from '@angular/core/testing';

import { MohanService } from './mohan.service';

describe('MohanService', () => {
  let service: MohanService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(MohanService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
