module.exports = {
    url: "mongodb+srv://mohan1:Mnj0701@cluster0.ilh6l.mongodb.net/DATABASE1?retryWrites=true&w=majority"
  };